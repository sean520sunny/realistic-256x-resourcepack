# 写实矿石与地形 256X 材质包

适用于 Minecraft Java 版（1.20.5+，兼容至 1.21.x）。

## 包含贴图
- grass_block_top.png 草方块顶部（写实草地）
- grass_block_side.png 草方块侧面（草皮 + 泥土过渡）
- grass_block_side_overlay.png 草皮覆盖层（支持生物群系染色）
- dirt.png 泥土（草方块底部）
- sand.png 沙子
- gravel.png 砂砾（碎石 + 鹅卵石）
- cobblestone.png 圆石
- stone.png 石头
- granite.png 花岗岩
- diorite.png 闪长岩
- basalt_side.png / basalt_top.png 玄武岩（侧面 + 顶底）
- sandstone_side.png / sandstone_top.png / sandstone_bottom.png 砂岩（侧 + 顶 + 底）
- dirt_path.png / dirt_path_side.png 土径（顶面 + 侧面）
- stone_bricks.png 石砖
- cracked_stone_bricks.png 裂纹石砖
- mossy_stone_bricks.png 苔藓石砖
- mossy_cobblestone.png 苔藓圆石
- chiseled_stone_bricks.png 錾制石砖
- chiseled_sandstone.png 錾制砂岩
- polished_granite.png 磨制花岗岩
- polished_diorite.png 磨制闪长岩
- polished_basalt_side.png / polished_basalt_top.png 磨制玄武岩
- smooth_basalt.png 平滑玄武岩
- cut_sandstone.png 切制砂岩

台阶、楼梯、墙、压力板、按钮等形状变体无需单独贴图，游戏会自动复用上方原方块贴图。

所有贴图均为 256×256 像素（錾制方块为整面居中浮雕，与游戏原版一致，不做平铺）。

## 安装方法
1. 打开游戏目录 .minecraft/resourcepacks
   （Windows 运行框输入 %appdata%/.minecraft/resourcepacks）
2. 把本文件夹（或 zip）放进去
3. 游戏内：选项 → 资源包 → 选中本材质包

## 提示
- 256X 对显卡有一定要求，低端设备若掉帧可换用 128X 版本。
- 写实纹理在不同光照下观感会有差异，属正常现象。
